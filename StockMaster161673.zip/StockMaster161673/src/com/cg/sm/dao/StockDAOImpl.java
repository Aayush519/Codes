package com.cg.sm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;



import com.cg.sm.dto.Client;

@Repository("daoObj")
public class StockDAOImpl  implements StockDAO
{
	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public List<Client> getAll() {
		
		String str="select stock from Client stock";
		TypedQuery<Client> queryOne=(TypedQuery<Client>) entitymanager.createQuery(str,Client.class);
		List<Client> myList=queryOne.getResultList();
		return myList;
		
	}

	@Override
	public Client getStock(int stid) {
		
		Client obj= entitymanager.find(Client.class,stid);	
		return obj;
	}

}
