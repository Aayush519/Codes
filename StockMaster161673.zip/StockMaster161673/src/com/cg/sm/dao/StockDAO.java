package com.cg.sm.dao;

import java.util.List;

import com.cg.sm.dto.Client;

public interface StockDAO {
	public List<Client> getAll();
	public Client getStock(int stid);
}
