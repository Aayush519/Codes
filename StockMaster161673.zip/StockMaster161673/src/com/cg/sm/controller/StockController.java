package com.cg.sm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.sm.dto.Client;
import com.cg.sm.service.StockService;

@Controller
public class StockController
{
	@Autowired
	StockService serviceObj;
	
	@RequestMapping("run")
	public String getAll(Model model)
	{
		List<Client> list = serviceObj.getAll();
		model.addAttribute("list",list);
		return "index";
	}
	
	
	@RequestMapping("settingOrder")
	public String setOrder(@RequestParam("stockId") int stc,Model model)
	{
		Client cobj= serviceObj.getStock(stc);
		model.addAttribute("data",cobj);
		return "order";
	}
	
	@RequestMapping("placingOrder")
	public String placeOrder(@ModelAttribute("data") Client client, 
			@RequestParam("qty") int qty,Model model)
	{
		double calculatedCost=client.getQuote()*qty;
		model.addAttribute("cost",calculatedCost);
		model.addAttribute("stock",client.getStock());
		return "summary";
	}
	
	
	
}
