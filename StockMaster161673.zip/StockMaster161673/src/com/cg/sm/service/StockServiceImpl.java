package com.cg.sm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.sm.dao.StockDAO;
import com.cg.sm.dto.Client;

@Service("serviceObj")
@Transactional
public class StockServiceImpl implements StockService 
{
	@Autowired
	StockDAO daoObj;
	
	@Override
	public List<Client> getAll() {
		return daoObj.getAll();
	}
	
	@Override
	public Client getStock(int stid) {

		return daoObj.getStock(stid);
	}

}
