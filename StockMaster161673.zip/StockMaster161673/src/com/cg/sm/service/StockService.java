package com.cg.sm.service;

import java.util.List;

import com.cg.sm.dto.Client;

public interface StockService {
	
	public List<Client> getAll();
	public Client getStock(int stid);

}
